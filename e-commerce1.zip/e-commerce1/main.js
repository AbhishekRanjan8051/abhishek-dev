var data_div = document.getElementById("data");

function storeItem() {
  let form = document.getElementById("myform");

  let name = document.getElementById("name").value;
  let price = document.getElementById("price").value;
  let image = document.getElementById("img").value;

  let location = {
    name,
    price,
    image,
  };

  let arr;

  arr = localStorage.getItem("location");

  if (arr == null) {
    arr = [];
  } else {
    arr = JSON.parse(localStorage.getItem("location"));
  }
  arr.push(location);

  localStorage.setItem("location", JSON.stringify(arr));
}

function appendCart() {
  var data_div = document.getElementById("data");

  var div = document.createElement("div");

  let p_name = document.createElement("p");

  p_name.innerHTML = el.name;

  let p_price = document.createElement("p");

  p_price.innerHTML = el.price;

  let img = document.createElement("img");

  img.src = el.img;

  let btn = document.createElement("button");
  btn.textContent = "Add to Cart";

  div.append(p_name, p_price, img, btn)
  
  data_div.append(div)
}
